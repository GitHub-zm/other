/**
 * 版权所有(C)，上海海鼎信息工程股份有限公司，2017，所有权利保留。
 * 
 * 项目名：	zxing
 * 文件名：	CreateQRCode.java
 * 模块说明：	
 * 修改历史：
 * 2017年11月20日 - liuhuazhen - 创建。
 */
package com.hd123.zxing;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/**
 * 生成二维码
 * 
 * @author liuhuazhen
 * 
 */
public class CreateQRCode {
  public static void main(String[] args) throws WriterException, IOException {
    String content = "http://www.hd123.com";  
    int width = 300; // 图像宽度  
    int height = 300; // 图像高度  
    String format = "png";// 图像类型  
    
    //定义二维码的参数
    Map<EncodeHintType, Object> hints = new HashMap<EncodeHintType, Object>();  
    hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");  
    hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
    hints.put(EncodeHintType.MARGIN, 2);
    
    //生成二维码
    BitMatrix bitMatrix = new MultiFormatWriter().encode(content,  
            BarcodeFormat.QR_CODE, width, height, hints);// 生成矩阵  
    File file = new File("E:/code/hd.png");  
    MatrixToImageWriter.writeToFile(bitMatrix, format, file);// 输出图像  
    System.out.println("输出成功.");  
    
  }
}
/**
 * 版权所有(C)，上海海鼎信息工程股份有限公司，2017，所有权利保留。
 * 
 * 项目名：	qrcode
 * 文件名：	MyQRCodeImage.java
 * 模块说明：	
 * 修改历史：
 * 2017年11月21日 - liuhuazhen - 创建。
 */
package com.hd123.qrcode;

import java.awt.image.BufferedImage;

import jp.sourceforge.qrcode.data.QRCodeImage;

/**
 * @author liuhuazhen
 * 
 */
public class MyQRCodeImage implements QRCodeImage {

  BufferedImage bufferedImage;

  public MyQRCodeImage(BufferedImage bufferedImage) {
    this.bufferedImage = bufferedImage;
  }

  // 宽
  @Override
  public int getWidth() {
    return bufferedImage.getWidth();
  }

  // 高
  @Override
  public int getHeight() {
    return bufferedImage.getHeight();
  }

  // 像素还是颜色
  @Override
  public int getPixel(int i, int j) {
    return bufferedImage.getRGB(i, j);
  }
}

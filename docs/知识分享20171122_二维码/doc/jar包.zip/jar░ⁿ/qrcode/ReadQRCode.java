/**
 * 版权所有(C)，上海海鼎信息工程股份有限公司，2017，所有权利保留。
 * 
 * 项目名：	zxing
 * 文件名：	ReadQRCode.java
 * 模块说明：	
 * 修改历史：
 * 2017年11月21日 - liuhuazhen - 创建。
 */
package com.hd123.qrcode;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import jp.sourceforge.qrcode.QRCodeDecoder;

/**
 * 读取二维码
 * 
 * @author liuhuazhen
 * 
 */
public class ReadQRCode {

  public static void main(String[] args) throws IOException {
    // 图片路径
    File file = new File("E:/code/baidu.png");
    // 读取图片到缓冲区
    BufferedImage bufferedImage = ImageIO.read(file);
    // QRCode解码器
    QRCodeDecoder codeDecoder = new QRCodeDecoder();
    // 通过解析二维码获得信息
    String result = new String(codeDecoder.decode(new MyQRCodeImage(bufferedImage)), "utf-8");
    System.out.println(result);
  }
}
